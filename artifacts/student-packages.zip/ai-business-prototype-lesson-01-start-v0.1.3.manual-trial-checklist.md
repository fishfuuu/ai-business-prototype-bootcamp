# Lesson 01 Start v0.1.3 主管电脑人工试用清单

## 候选包信息

- 候选包：`ai-business-prototype-lesson-01-start-v0.1.3.zip`
- 配套校验文件：`ai-business-prototype-lesson-01-start-v0.1.3.zip.sha256`
- Source Commit：`377d580d551929e6a04cc731ddccf943050f856a`
- 自动验收状态：`AUTOMATED_VALIDATION_PASS`
- 人工试用状态：`MANUAL_TRIAL_PENDING`

说明：本清单未完成前，**v0.1.3 不得称为正式发布包**。

## A. 试用环境记录

填写：

- 试用人：
- 部门和岗位：
- 电脑系统：
- 是否有管理员权限：
- Node.js版本：
- npm版本：
- Claude Code版本：
- 是否安装Git：
- 开始时间：
- 完成时间：

## B. 文件接收

检查：

- [ ] 收到ZIP
- [ ] 收到sha256
- [ ] ZIP文件名正确（`ai-business-prototype-lesson-01-start-v0.1.3.zip`）
- [ ] 可选：重新计算ZIP SHA256并与校验文件一致  
      期望SHA256：`8f88551d14671d4247e6cd8d0ca9fd84740b94a7629df8bba88635c7bc2b3998`

## C. 解压

检查：

- [ ] 没有直接在ZIP内运行
- [ ] 解压到本地普通目录
- [ ] 推荐目录为 `D:\AIPrototype`
- [ ] 没有覆盖已有同名项目
- [ ] 可以看到 `START_HERE.md` 和 `package.json`

## D. 环境

执行：

```powershell
node --version
npm --version
```

检查：

- [ ] Node.js不低于20.19.0
- [ ] npm可用
- [ ] Claude Code可启动

## E. 安装依赖

执行：

```powershell
npm ci
```

检查：

- [ ] 安装成功
- [ ] 没有要求公司账号、Token或业务系统权限
- [ ] 记录安装耗时：
- [ ] 记录完整错误信息（如失败）：

## F. 启动

双击：

`start-project.bat`

检查：

- [ ] 开发服务器启动
- [ ] 浏览器能打开 `http://127.0.0.1:8888/#/`
- [ ] 组件页能打开 `http://127.0.0.1:8888/#/components`
- [ ] 页面没有明显空白或报错
- [ ] 记录启动耗时：

## G. 项目验证

执行：

```powershell
powershell -ExecutionPolicy Bypass -File .\scripts\verify-student-project.ps1
```

检查：

- [ ] 验证成功
- [ ] typecheck成功
- [ ] build成功
- [ ] `dist\index.html` 存在

## H. Claude Code只读上手检查

打开Claude Code后输入：

```text
请先只读以下文件，不要修改任何文件：

START_HERE.md
README.md
CLAUDE.md
DESIGN.md
docs/COMPONENT_CATALOG.md
docs/LESSON_01_GUIDE.md

然后请用业务主管能够理解的方式回答：

1. 这个项目是做什么的？
2. 第一课需要我提供哪5项业务信息？
3. 本项目明确不能使用哪些真实数据或接口？
4. 修改页面前你需要先向我说明什么？
5. 完成修改后要执行哪些验证？
```

检查：

- [ ] Claude Code能读取项目
- [ ] 没有要求GitHub
- [ ] 没有要求真实API或.env
- [ ] 能正确说明第一课5项业务信息
- [ ] 能正确说明模拟数据和安全边界
- [ ] 没有修改任何文件

## I. 易用性反馈

评分1至5：

- 解压是否清楚：
- 安装是否顺利：
- 启动是否顺利：
- 文档是否能看懂：
- Claude Code规则是否清楚：
- 是否有信心继续第一课：

记录：

- 最困惑的步骤：
- 最耗时的步骤：
- 错误截图：
- 希望补充的说明：
- 是否建议正式发放：

## J. 人工结论

只能选择一个：

- [ ] MANUAL_TRIAL_PASS
- [ ] MANUAL_TRIAL_PASS_WITH_MINOR_FIXES
- [ ] MANUAL_TRIAL_FAIL

课程负责人结论：

- [ ] 批准后续正式发放准备
- [ ] 修改后重新生成新版本
- [ ] 暂停发放

明确：

本清单未完成前，v0.1.3不得称为正式发布包。